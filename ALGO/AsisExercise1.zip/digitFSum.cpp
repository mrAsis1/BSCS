#include <bits/stdc++.h>
using namespace std;

unsigned long long int getfactorial(int n);
unsigned long long int getDigitFactoralSum(unsigned long long int n);

int main() {
    srand(time(0));
    ofstream outfile("results.txt");

    for (int size = 100000; size <= 2000000; size += 100000) {
        
        clock_t start = clock(); 
        
        for (int i = 0; i < size; ++i) {
            
            unsigned long long int num = rand() % 1000000; 
            getDigitFactoralSum(num);
        }
        
        clock_t end = clock(); 
        double time_taken = double(end - start) / CLOCKS_PER_SEC;
        
        outfile << size << " " << time_taken << endl;
        cout << "Processed " << size << " inputs in " << time_taken << "s" << endl;
    }

    outfile.close();
    return 0;
}

unsigned long long int getfactorial(int n) {
    unsigned long long int temp = 1;
    if (n < 0) return 0;
    while (n > 0) {
        temp *= n;
        n--;
    }
    return temp;
}

unsigned long long int getDigitFactoralSum(unsigned long long int n) {
    unsigned long long int sum = 0;
    while(n > 0) {
        int digit = n % 10;
        sum += getfactorial(digit);
        n /= 10;
    }
    return sum;
}